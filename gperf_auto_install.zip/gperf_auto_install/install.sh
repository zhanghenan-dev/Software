#!/bin/bash

chmod 777 *
unzip libunwind-vanilla_pathscale.zip
unzip gperftools-2.6.1.zip 

cd libunwind-vanilla_pathscale/
./autogen.sh
./configure
make
make install

cd ..
cd gperftools-2.6.1/
./configure
make
make install

cd ../
rpm -i libXaw-1.0.13-4.el7.x86_64.rpm
rpm -i graphviz-2.30.1-21.el7.x86_64.rpm

